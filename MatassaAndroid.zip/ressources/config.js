module.exports = {
    URL: `https://matassa.herokuapp.com/mobile/api/v1`,
    mesures: [{
        titre: 'Bien se laver les mains',
        description: "Se laver fréquemment les mains avec une solution hydroalcoolique ou à l'eau et au savon",
        image: 'mains'
    }, {
        titre: 'Eviter les contacts proches',
        description: "Maintenir une distance d'au moins 1 mètre avec les autres personnes, en particulier si elles toussent, éternuent, ou ont de la fièvre.",
        image: 'distance'
    }, {
        titre: 'Eviter tout contact avec des objets de personnes malades',
        description: "Bien essuyer les objets usés des malades.",
        image: 'contacts'
    }, {
        titre: 'Eviter au maximum de se toucher le visage',
        description: "Car les mains sont en contact avec de nombreuses surfaces qui peuvent être contaminées par le virus. Si vous vous touchez les yeux, le nez ou la bouche, vous risquez d'être en contact avec le virus présent sur ces surfaces.",
        image: 'mains'
    }],
    symptomes: [{
        titre: 'Température',
        description: "Forte fièvre ou température élevée.",
        image: 'temperature'
    }, {
        titre: 'Respiration',
        description: "Troubles ou difficultés respiratoires.",
        image: 'respiration'
    }, {
        titre: 'Toux sèches',
        description: "Toux sèche et fréquente.",
        image: 'tousser'
    }, {
        titre: 'Fatigue',
        description: "Fatigue longue et générale.",
        image: 'fatigue'
    }],

    sondages: [{
        _id: 2,
        question: "Avez-vous respecté le couvre-feu ?",
        // description: "Bon, maintenant je ne sais pas quoi dire !",
        type: '__RADIO__',
        responses: [{
            label: "Oui",
            value: '__YES__'
        }, {
            label: "Non",
            value: "__NO__"
        }, {
            label: "Peut-être",
            value: "__MAYBE__"
        }],
        selectedResponses: []
    }],

    ages: [{
        label: '0-15',
        value: '0-15'
    }, {
        label: '16-25',
        value: '16-25'
    }, {
        label: '26-35',
        value: '26-35'
    }, {
        label: '36-50',
        value: '36-50'
    }, {
        label: '50 +',
        value: '50 +'
    }],

    regions: [{
        label: 'Agadez',
        value: 'Agadez'
    }, {
        label: 'Diffa',
        value: 'Diffa'
    }, {
        label: 'Dosso',
        value: 'Dosso'
    }, {
        label: 'Maradi',
        value: 'Maradi'
    }, {
        label: 'Niamey',
        value: 'Niamey'
    }, {
        label: 'Tahoua',
        value: 'Tahoua'
    }, {
        label: 'Tillabéri',
        value: 'Tillabéri'
    }, {
        label: 'Zinder',
        value: 'Zinder'
    }]

}
