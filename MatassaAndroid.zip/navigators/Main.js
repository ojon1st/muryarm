import React from 'react';
import Icon from 'react-native-vector-icons/FontAwesome5';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';

const Tab = createMaterialBottomTabNavigator();

// Screens.

import Informations from './Informations';
import Sondages from './Sondages';
import Forum from './../components/Forum';

const ICON_SIZE = 20;
function setIcon(iconName) {
    return (
        ({ focused, color }) => <Icon focused={focused} name={iconName} color={color} size={ICON_SIZE} />
    );
}

export default class Main extends React.Component {

    render() {
        return (
            <>
                <Tab.Navigator
                    initialRouteName="Informations"
                    activeColor="#0062FFff"
                    inactiveColor="#0062FF64"
                    barStyle={{
                        backgroundColor: '#ffffff'
                    }}
                >

                    <Tab.Screen
                        name="Informations"
                        component={Informations}
                        options={{
                            tabBarLabel: 'Informations',
                            tabBarIcon: setIcon('info-circle')
                        }}
                    />

                    <Tab.Screen
                        name="Sondages"
                        component={Sondages}
                        options={{
                            tabBarLabel: 'Sondages',
                            tabBarIcon: setIcon('question-circle')
                        }}
                    />

                    <Tab.Screen
                        name="Forum"
                        component={Forum}
                        options={{
                            tabBarLabel: 'Forum',
                            tabBarIcon: setIcon('comments')
                        }}
                    />

                </Tab.Navigator>
            </>
        )
    }
}