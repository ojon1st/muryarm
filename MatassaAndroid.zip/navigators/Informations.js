import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Accueil from '../components/Accueil';
import Reporter from '../components/Reporter';

let Stack = createNativeStackNavigator();


class Informations extends React.Component {
    render() {
        return (
            <Stack.Navigator screenOptions={{
                headerTitleStyle: {
                    color: 'darkblue'
                }
            }}>

                <Stack.Screen
                    name="Accueil"
                    component={Accueil}
                    options={{
                        headerShown: false
                    }}
                />

                <Stack.Screen
                    name="Reporter"
                    component={Reporter}
                />

            </Stack.Navigator>
        );
    }
}


export default Informations;