import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import SondageList from '../components/SondageList';
import UserForm from '../components/UserForm';

let Stack = createNativeStackNavigator();


class Sondages extends React.Component {
    render() {
        return (
            <Stack.Navigator screenOptions={{
                headerTitleStyle: {
                    color: 'darkblue'
                }
            }}>

                <Stack.Screen
                    name="Sondages"
                    component={SondageList}
                    options={{
                        headerShown: false
                    }}
                />

                <Stack.Screen
                    name="UserForm"
                    component={UserForm}
                    options={{
                        headerShown: false
                    }}
                />

            </Stack.Navigator>
        );
    }
}


export default Sondages;