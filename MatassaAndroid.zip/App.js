import React from 'react';
import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { enableScreens } from 'react-native-screens';

enableScreens();

import MainNavigator from './navigators/Main';
import Splash from './components/Splash';

export default class App extends React.Component {
  state = {
    isLoading: true
  }

  componentDidMount() {
    setTimeout(() => {
      this.setState({
        isLoading: false
      });
    }, 2000);
  }
  render() {
    if(this.state.isLoading) {
      return <Splash />
    }
    return (
      <NavigationContainer>
        <StatusBar backgroundColor='#f5f5f5' barStyle="dark-content" animated />
        <MainNavigator />
      </NavigationContainer>
    );
  }
}
