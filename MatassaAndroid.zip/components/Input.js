import React from 'react';
import Styled from 'styled-components/native';

const Container = Styled.View`
    flex-direction: row;
    align-items: center;
    padding: 4px;
`;

const Case = Styled.TouchableOpacity`
    height: 20px;
    width: 20px;
    border: 1px solid #0062FF;
    margin-right: 5px;
`;

const Label = Styled.Text`
    color: #999;
    font-size: 15px;
`;

class Input extends React.Component {

    state = {
        focused: false,
    }

    ref = null

    constructor(props) {
        super();
        if(props.reference) props.reference(this);
    }

    onPress = () => {
        if(this.props.type == '__CHECKBOX__') {
            if(this.state.focused) {
                return this.props.onDeselect(this.props.item.value);
            }
        }
        this.props.onSelect(this.props.item.value);
    }

    focus() {
        this.setState({
            focused: true
        });
    }

    blur() {
        this.setState({
            focused: false
        });
    }

    render() {
        return (
            <Container>
                <Case onPress={this.onPress} style={{backgroundColor: this.state.focused ? '#0062FF': '#fff', borderRadius: this.props.type == '__RADIO__' ? 100:3}} />
                <Label>{this.props.item.label}</Label>
            </Container>
        )
    }
    
}

export default Input;