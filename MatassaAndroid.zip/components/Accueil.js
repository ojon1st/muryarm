import React from 'react';
import { StatusBar, ActivityIndicator, RefreshControl } from 'react-native';
import Styled from 'styled-components/native';
import Icon from 'react-native-vector-icons/FontAwesome5';

import distance from '../assets/distance_entre_personnes.png';
import contacts from '../assets/eviter_les_contacts.png';
import fatigue from '../assets/fatigue.png';
import mains from '../assets/laver_les_mains.png';
import respiration from '../assets/respiration.png';
import temperature from '../assets/temperature.png';
import tousser from '../assets/tousser.png';
import virus from '../assets/virus.png';

let images = { distance, contacts, fatigue, mains, respiration, temperature, tousser };

import { URL, mesures, symptomes } from '../ressources/config';

const Container = Styled.ScrollView`
    backgroundColor: #f5f5f5;
`;

const Header = Styled.ImageBackground`
    height: 200px;
    background-color: #0062FFb4;
    align-items: center;
    justify-content: center;
    paddingHorizontal: 15px;
    resizeMode: cover;
`;

const BoldTitle = Styled.Text`
    font-weight: bold;
    color: #fff;
    font-size: 28px;
    line-height: 30px;
    text-align: center;
`;

const LightTitle = Styled.Text`
    color: rgba(250,250,250, 0.8);
    text-align: center;
    margin-top: 5px;
`;

const Body = Styled.View`
    flex: 1;
`;

const Statistiques = Styled.View`
    padding: 10px;
    margin: 10px 5px;
    border-radius: 4px;
    background-color: #fff;
    elevation: 1;
`;

const Title = Styled.Text`
    color: #0062FFB3;
    margin-bottom: 5px;
    font-size: 17px;
`;

const Cas = Styled.View`
    flex: 1;
    flex-direction: row;
    align-items: center;
    margin: 5px 10px;
`;

const BadgeConfirm = Styled.Text`
    background-color: #f14668;
    padding: 0px 8px;
    border-radius: 4px;
    margin: 0 8px;
    min-width: 30px;
    text-align: right;
    font-size: 14px;
    color: #fff;
`;

const BadgeGuerison = Styled(BadgeConfirm)`
    background-color: #48C774;
`;

const BadgeDeces = Styled(BadgeConfirm)`
    background-color: #363636;
`;

const Label = Styled.Text`
    color: grey;
    font-size: 14px;
`;

const GrosTitle = Styled.Text`
    font-size: 25px;
    color: #0062FF;
    text-align: center;
    line-height: 25px;
    padding: 10px;
    border-radius: 4px;
    margin: 10px;
    background-color: #fff;
    elevation: 1;
    font-weight: bold;
`;

const Mesure = Styled.View`
    padding: 10px 20px;
    background-color: #fff;
    elevation: 1;
    border-radius: 4px;
    margin: 5px;
    align-items: center;
`;

const Image = Styled.Image`
    height: 110px;
    resizeMode: contain;
    margin: 4px 0;
`;

const Titre = Styled.Text`
    font-weight: bold;
    font-size: 16px;
    text-align: center;
    color: #0062FF;
    width: 85%;
    margin: 5px 0;
`;

const Description = Styled.Text`
    color: #999;
    text-align: justify;
    font-size: 14px;
`;

const Loader = Styled.View`
    height: 100px;
    align-items: center;
    justify-content: center;
`;

const Text = Styled.Text`
    color: #999;
    font-size: 14px;
    margin-left: 5px;
`;

const Reporter = Styled.TouchableOpacity`
    flex-direction: row;
    align-items: center;
    justify-content: center;
    elevation: 1;
    padding: 10px;
    background-color: red;
    border-radius: 2px;
    align-items: center;
    margin: 2px 10px;
`;

class Accueil extends React.Component {

    state = {
        confirmations: 24,
        deces: 3,
        guerisons: 0,
        isLoading: true,
        refreshing: false
    }

    focusListener = null
    timeout = null

    onRefresh = () => {
        this.setState({
            refreshing: true,
            isLoading: true
        });
        this.getData();
    }

    getData() {
        return fetch("https://covid-193.p.rapidapi.com/statistics?country=Niger", {
            method: "GET",
            mode: 'cors',
            headers: {
                "x-rapidapi-host": "covid-193.p.rapidapi.com",
                "x-rapidapi-key": "d64ba78c0emsh92effe003e9aea5p1c7288jsnab2a88cfdb6a"
            }
        }).then(res => res.json())
        .then(({response}) => {
            let [stats] = response;
            this.setState({
                deces: stats.deaths.total,
                guerisons: stats.cases.recovered,
                confirmations: stats.cases.total,
                refreshing: false,
                isLoading: false
            });
            console.log(stats.cases, stats.deaths);
        }).catch(() => this.setState({ isLoading: false, refreshing: false }));
    }

    UNSAFE_componentWillMount() {
        this.timeout = setInterval(() => {
            this.getData();
        }, 1*60*1000);
        this.getData();
    }

    componentDidMount() {
        this.focusListener = this.props.navigation.addListener('focus', () => {
            StatusBar.setBackgroundColor('#0062FF', false);
            StatusBar.setBarStyle('light-content');
        });
    }

    componentWillUnmount() {
        clearInterval(this.timeout);
        this.props.navigation.removeListener(this.focusListener);
    }

    declarerUnCas = () => {
        this.props.navigation.navigate('Reporter');
    }

    render() {
        return (
            <Container refreshControl={<RefreshControl colors={['#0062FF']} refreshing={this.state.refreshing} onRefresh={this.onRefresh} />}>
                <StatusBar backgroundColor='#0062FF' barStyle='light-content' />
                <Header source={virus}>
                    <BoldTitle>La jeunesse du Niger s'engage contre le Coronavirus...</BoldTitle>
                    <LightTitle>#Covid19 - NIGER</LightTitle>
                </Header>
                <Body>
                    <Statistiques>
                        <Title>Statistiques générales</Title>
                        {this.state.isLoading && (
                            <Loader>
                                <ActivityIndicator color="#0062FF" />
                            </Loader>
                        )}
                        {!this.state.isLoading && (
                            <>
                                <Cas>
                                    <Icon name='users' size={18} style={{width: 20}} />
                                    <BadgeConfirm>{this.state.confirmations}</BadgeConfirm>
                                    <Label>Cas confirmés</Label>
                                </Cas>
                                <Cas>
                                    <Icon name='thumbs-up' size={18} style={{width: 20}} />
                                    <BadgeGuerison>{this.state.guerisons}</BadgeGuerison>
                                    <Label>Personnes guéries</Label>
                                </Cas>
                                <Cas>
                                    <Icon name='user-alt-slash' size={18} style={{width: 20}} />
                                    <BadgeDeces>{this.state.deces}</BadgeDeces>
                                    <Label>Décès</Label>
                                </Cas>
                            </>
                        )}
                    </Statistiques>
                    
                    <Reporter onPress={this.declarerUnCas}>
                        <Icon name="ambulance" color="#fff" size={15} />
                        <Text style={{color: '#fff', fontWeight: 'bold'}}>CLIQUEZ POUR DECLARER UN CAS</Text>
                    </Reporter>
                    
                    <GrosTitle>Prévention</GrosTitle>

                    {mesures.map((mesure, index) => (
                            <Mesure key={++index}>
                                <Image source={images[mesure.image]} />
                                <Titre>{mesure.titre}</Titre>
                                <Description>{mesure.description}</Description>
                            </Mesure>
                        )
                    )}

                    <GrosTitle>Symptômes</GrosTitle>

                    {symptomes.map((symptome, index) => (
                            <Mesure key={++index}>
                                <Image source={images[symptome.image]} />
                                <Titre>{symptome.titre}</Titre>
                                <Description>{symptome.description}</Description>
                            </Mesure>
                        )
                    )}
                </Body>
            </Container>
        );
    }
}


export default Accueil;