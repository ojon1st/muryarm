import React from 'react';
import Styled from 'styled-components/native';

import Input from './Input';


class RadioGroup extends React.Component {

    inputs = {}
    selected = []

    constructor(props) {
        super();
        if(props.reference) props.reference(this);
    }

    getResults() {
        return this.selected;
    }
    
    onSelect = (value) => {
        if(this.props.type == '__RADIO__') {
            for(let id of this.selected) {
                this.inputs[id].blur();
            }
            this.selected = [];
        }
        this.inputs[value].focus();
        this.selected.push(value);
    }

    onDeselect = (value) => {
        this.inputs[value].blur();
        this.selected = this.selected.filter(s => s != value);
    }

    render() {
        return (this.props.data.map(d => {
            return (
                <Input
                    key={d.value.toString()} 
                    type={this.props.type} 
                    reference={ref => this.inputs[d.value] = ref} 
                    onDeselect={this.onDeselect} 
                    onSelect={this.onSelect} 
                    item={d}
                    inline={!!this.props.inline}
                />
            )
        }));
    }

    
}

export default RadioGroup;