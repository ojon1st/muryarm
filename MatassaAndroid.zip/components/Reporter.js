import React from 'react';
import { ActivityIndicator } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import RDropdown from 'react-native-picker-select';
import Styled from 'styled-components/native';

import {ages, regions, URL} from '../ressources/config';

const Container = Styled.ScrollView`
    background-color: #f5f5f5;
`;

const Title = Styled.Text`
    text-align: center;
    color: #0062FFB4;
    font-size: 17px;
    line-height: 18px;
    margin: 20px 30px;
    margin-top: 40px;
    font-weight: bold;
`;

const Form = Styled.View`
    margin: 10px;
`;

const Input = Styled.TextInput`
    background-color: #FFF;
    padding: 10px;
    margin: 5px;
    font-size: 16px;
    border-radius: 4px;
    elevation: 1;
    color: #0062FF;
`;

const SelectContainer = Styled.View`
    flex-direction: row;
    align-items: center;
`;

const Age = Styled.View`
    background-color: #FFF;
    flex: 1;
    padding: 0 4px;
    border-radius: 4px;
    elevation: 1;
    color: #0062FF;
    margin: 5px;
    margin-right: 3px;
    padding: 10px;
`;

const Region = Styled(Age)`
    margin-right: 5px;
    margin-left: 3px;
`;

const Button = Styled.TouchableOpacity`
    margin: 5px
    padding: 15px;
    background-color: #0062FF;
    elevation: 1;
    border-radius: 4px;
    flex-direction: row;
    align-items: center;
    justify-content: center;
`;

const Text = Styled.Text`
    color: #fff;
    font-weight: bold;
    margin: 0 7px;
`;

const Message = Styled.Text`
    position: absolute;
    top: 0;
    width: 100%;
    padding: 4px 10px;
    background-color: red;
    color: #fff;
    font-weight: bold;
    elevation: 2;
    zIndex: 100000
`;

const SuccessContainer = Styled.View`
    flex: 1;
    align-items: center;
    justify-content: center;
`;

const SuccessMessage = Styled.Text`
    width: 80%;
    margin-top: 20px;
    color: #0062FF;
	font-weight: bold;
	text-align: center;
`;

class Reporter extends React.Component {

    state = {
        nomPrenom: '',
        age: '',
        region: '',
        localite: '',
        telephone: '',
        message: false,
        sent: false
    }

    blurListener = null

    componentDidMount() {
        this.props.navigation.setOptions({
            title: 'Déclaration',
            headerTitleStyle: {
                fontSize: 9,
                color: '#0062FF'
            }
        });


        // this.blurListener = this.props.navigation.addListener('blur', () => {
        //     console.log('bluring')
        //     this.props.navigation.pop();
        // });
    }

    // componentWillUnmount() {
    //     // this.props.navigation.removeListener(this.blurListener);
    // }

    sendAlert = () => {

        const {
            nomPrenom,
            age,
            region,
            localite,
            telephone
        } = this.state;

        if(!(age && nomPrenom && region && localite && telephone)) {
            return this.setState({
                message: "Vous n'avez pas renseigné certaines informations."
            });
        }
        this.setState({
            isLoading: true
        });
        fetch(`${URL}/sendAlert`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nomPrenom,
                age,
                region,
                localite,
                telephone
            })
        }).then(res => res.json())
        .then(response => {
            if(response.success) {
                this.setState({
                    isLoading: false,
                    sent: response.moreInfos
                });
            } else {
                this.setState({
                    isLoading: false,
                    message: response.moreInfos
                });
            }
        }).catch(err => {
            console.log(err);
            this.setState({
                isLoading: false,
                message: "Nous n'arrivons pas à envoyer votre alerte, merci de vérifier votre connexion à Internet."
            });
        });
    }

    onNomPrenomChange = (nomPrenom) => {
        this.setState({
            nomPrenom
        });
    }

    onAgeSelected = (age) => {
        this.setState({
            age
        });
    }

    onRegionSelected = (region) => {
        this.setState({
            region
        });
    }

    onLocaliteChange = (localite) => {
        this.setState({
            localite
        });
    }

    onTelephoneChange = (telephone) => {
        this.setState({
            telephone
        });
    }

    successMessage() {
        return (
            <SuccessContainer>
                <Icon name="check" size={30} color='green' />
                <SuccessMessage>
                    {this.state.sent}
                </SuccessMessage>
            </SuccessContainer>
        )
    }

    render() {
        if(this.state.sent) {
            return this.successMessage();
        }
        return (
            <Container>
                {this.state.message && (<Message>{this.state.message}</Message>)}
                <Title>Si vous ou un de vos proches détectez un de ces symptômes, remplissez ce formulaire</Title>
                <Form>
                    <Input
                        placeholder="Nom et prénoms"
                        value={this.state.nomPrenom}
                        returnKeyType="next"
                        blurOnSubmit={true}
                        autoCompleteType="off"
                        onChangeText={this.onNomPrenomChange}
                    />
                    <SelectContainer>
                        <Age>
                            <RDropdown
                                useNativeAndroidPickerStyle={false}
                                Icon={() => <Icon name="chevron-down" color='#0062FF' size={15} />}
                                style={{ inputAndroid: { color: '#0062FF', fontSize: 17 }, iconContainer: { top: 6, right: 6 } }}
                                onValueChange={this.onAgeSelected}
                                value={this.state.age}
                                placeholder={{ label: 'Age', value: null, disabled: true }}
                                items={ages}
                            />
                        </Age>
                        <Region>
                            <RDropdown
                                useNativeAndroidPickerStyle={false}
                                Icon={() => <Icon name="chevron-down" color='#0062FF' size={15} />}
                                style={{ inputAndroid: { color: '#0062FF', fontSize: 17 }, iconContainer: {top: 6, right: 6}}}
                                onValueChange={this.onRegionSelected}
                                value={this.state.region}
                                placeholder={{ label: 'Région', value: null, disabled: true }}
                                items={regions}
                            />
                        </Region>
                        
                    </SelectContainer>
                    <Input
                        placeholder="Localité"
                        value={this.state.localite}
                        returnKeyType="next"
                        blurOnSubmit={true}
                        autoCompleteType="off"
                        onChangeText={this.onLocaliteChange}
                    />
                    <Input
                        placeholder="Numéro de téléphone"
                        value={this.state.telephone}
                        returnKeyType="next"
                        blurOnSubmit={true}
                        keyboardType="phone-pad"
                        autoCompleteType="off"
                        onChangeText={this.onTelephoneChange}
                    />
                    <Button disabled={this.state.isLoading} onPress={this.sendAlert}>
                        {this.state.isLoading && (<ActivityIndicator color='#FFF' />)}
                        <Text>Envoyer</Text>
                    </Button>
                </Form>
            </Container>
        )
    }
}

export default Reporter;
