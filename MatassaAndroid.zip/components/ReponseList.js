import React from 'react';
import Styled from 'styled-components/native';

const Container = Styled.View`
    padding: 10px;
`;

const Info = Styled.Text`
    color: red;
    margin: 4px 0;
`;

class ReponseList extends React.Component {

    state = {
        responses: [],
        invalid: false
    }

    ref = null

    constructor(props) {
        super();
        if (props.ref) props.ref(this);
    }

    getResults() {
        return this.state.responses;
    }

    setInvalid(invalid) {
        this.setState({
            invalid
        })
    } 

    onChoose = ({_id}) => {
        this.setState({
            responses: [...this.state.responses.filter(r => r != _id.toString()), _id.toString()]
        });
    }

    render() {
        let styles = {};
        if(!!this.props.inline) {
            styles = {
                flexDirection: 'row', 
                alignItems: 'center' 
            };
        }
        return (
            <Container style={styles}>
                {(this.state.invalid) && (<Info>Vous devez choisir une réponse</Info>)}
                { this.props.create({ responses: this.props.responses, _id: this.props._id, choose: this.onChoose, type: this.props.type }) }
            </Container>
        );
    }
}

export default ReponseList;