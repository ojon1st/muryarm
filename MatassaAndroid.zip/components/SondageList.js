import React from 'react';
import { StatusBar, ActivityIndicator, View, AsyncStorage, RefreshControl } from 'react-native';
import Styled from 'styled-components/native';

// import AsyncStorage from '@react-native-community/async-storage';

import ReponseList from './ReponseList';
import RadioGroup from './RadioGroup';

import { URL, sondages } from '../ressources/config';

const Container = Styled.ScrollView`
    background-color: #f5f5f5;
`;

const TitleContainer = Styled.View`
    padding: 10px;
    align-items: center;
    justify-content: center;
    background-color: #fff;
    elevation: 1;
    border-radius: 4px;
    margin: 5px;
`;

const Title = Styled.Text`
    color: #0062FF;
    text-align: center;
    font-weight: bold;
    font-size: 25px;
`;

const Description = Styled.Text`
    color: #999;
    text-align: center;
    width: 80%;
    margin: 4px;
`;

const QuestionContainer = Styled.View`
    padding: 10px;
    background-color: #fff;
    elevation: 1;
    border-radius: 4px;
    margin: 5px;
`;

const Question = Styled.Text`
    color: #0062FF;
    margin: 3px;
    font-size: 17px;
    width: 100%;
    font-weight: bold;
`;

const Hr = Styled.View`
    margin-top: 5px;
    height: 1px;
    width: 50%;
    border-top-width: 1px;
    border-top-color: #0062FF;
`;

const ButtonContainer = Styled.View`
    width: 100%;
    align-items: center;
    padding: 10px;
    margin: 10px;
`;

const Button = Styled.TouchableOpacity`
    background-color: #0062FF;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    width: 80%;
    border-radius: 4px;
    padding: 10px;
`;

const Text = Styled.Text`
    color: #fff;
    font-weight: bold;
    text-align: center;
`;

const Message = Styled.Text`
    position: absolute;
    top: 0;
    width: 100%;
    padding: 4px 10px;
    background-color: red;
    color: #fff;
    font-weight: bold;
    elevation: 2;
    zIndex: 100000
`;

const Response = Styled.View`
    flex-direction: row;
    align-items: flex-start;
    padding: 2px 10px;
`;

const Label = Styled.Text`
    font-size: 14px;
    flex: 1;
    color: #999;
`;

const Pourcentage = Styled.Text`
    font-size: 18px;
    font-style: italic;
    color: #0062FF;
    min-width: 60px;
    text-align: right;
`;

class SondageList extends React.Component {

    focusListener = null
    results = {}

    state = {
        message: false,
        showResults: false,
        isLoading: true,
        sondages: [],
        refreshing: false,
        results: [],
        waitingAuth: false,
        btnLoading: false
    }

    getResults() {
        return fetch(`${URL}/sondageResults`).then(res => res.json()).then(res => {
            if (res.success) {
                this.setState({
                    showResults: true,
                    isLoading: false,
                    refreshing: false,
                    results: res.data
                })
            }
        }).catch(console.log);
    }

    componentDidMount() {
        AsyncStorage.getItem('@muryarmatassa:sondages').then(sended => {
            console.log(sended)
            if(!sended) {
                fetch(`${URL}/sondageList`).then(res => res.json()).then(res => {
                    if (res.success) {
                        this.setState({
                            showResults: false,
                            isLoading: false,
                            sondages: res.data
                        })
                    }
                }).catch(console.log)
            } else {
                this.getResults();
            }
        }).catch(console.log);

        this.focusListener = this.props.navigation.addListener('focus', () => {
            StatusBar.setBackgroundColor('#0062FF', false);
            StatusBar.setBarStyle('light-content');
            if(this.state.waitingAuth) {
                this.sendMyAnswers();
            }
        });
    }

    componentWillUnmount() {
        this.props.navigation.removeListener(this.focusListener);
    }

    createResponseList = ({responses, choose, type, _id}) => {
        return (
            <RadioGroup
                reference={ref => this.results[_id] = ref}
                type={type}
                data={responses}
            />
        );
    }

    sendMyAnswers = async (fromClick=false) => {
        
        let answers = Object.keys(this.results).map(v => ({ sondageId: v, data: this.results[v].getResults() }));
        if (!answers.every(a => a.data.length > 0)) {
            this.setState({
                message: "Vous devez répondre à toutes les questions"
            });
        } else {
            console.log('On envoie la réponse.')
            try {
                this.setState({
                    message: false,
                    btnLoading: true,
                    waitingAuth: true
                });
                let user = await AsyncStorage.getItem('@muryarmatassa:user');
                if(user) {
                    user = JSON.parse(user);
                } else {
                    if (fromClick) {
                        this.props.navigation.navigate('UserForm');
                    } else {
                        throw new Error('Une erreur est survenue')
                    }
                }
                try {
                    let r = await fetch(`${URL}/addResponses`, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            userId: user._id,
                            responses: answers
                        })
                    }).then(res => res.json());
                    if(r.success) {
                        await AsyncStorage.setItem('@muryarmatassa:sondages', 'true');
                        this.setState({
                            isLoading: true,
                            message: false,
                            btnLoading: false,
                            waitingAuth: false
                        });
                        this.getResults();
                    } else {
                        this.setState({
                            message: r.moreInfos,
                            btnLoading: false,
                            waitingAuth: false
                        });
                    }
                } catch(err) {
                    console.log(err.message)
                    this.setState({
                        message: "Nous n'arrivons pas à envoyer vos réponse, veuillez vérifier votre connexion à Internet.",
                        btnLoading: false
                    });
                }
            } catch(err) {
                console.log(err)
                this.setState({
                    btnLoading: false,
                    waitingAuth: false
                })
            }
        }
    }

    onRefresh = () => {
        this.setState({
            refreshing: true
        });
        this.getResults();
    }

    showResults() {
        return (
            <Container refreshControl={<RefreshControl colors={['#0062FF']} refreshing={this.state.refreshing} onRefresh={this.onRefresh} />}>
                <StatusBar backgroundColor='#0062FF' barStyle='light-content' />
                <TitleContainer>
                    <Title>Sondages</Title>
                    <Description>Résultas des sondages</Description>
                </TitleContainer>
                {this.state.results.map((result, index) => (
                    <QuestionContainer key={++index}>
                        <Question>{result.question}</Question>
                        <Hr />
                        {result.responses.map((response, _index) => {
                            return (
                                <Response key={++_index}>
                                    <Label>{response.label}</Label>
                                    <Pourcentage>{Math.floor(response.nombre*10000/(result.total || 1))/100}%</Pourcentage>
                                </Response>
                            )
                        })}
                    </QuestionContainer>
                ))}
            </Container>
        )
    }

    render() {
        if(this.state.isLoading) {
            return (
                <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                    <ActivityIndicator size="large" color="#0062FF" />
                    <Text style={{color: '#0062FF', marginTop: 10}}>Chargement en cours</Text>
                </View>
            )
        }
        if (this.state.showResults) {
            return this.showResults();
        }
        return (
            <Container>
                {this.state.message && (<Message>{this.state.message}</Message>)}
                <StatusBar backgroundColor='#0062FF' barStyle='light-content' />
                <TitleContainer>
                    <Title>Sondages</Title>
                    <Description>Aidez-nous à récueillir des informations en répondant à ces questions</Description>
                </TitleContainer>
                {this.state.sondages.map((sondage, index) => (
                    <QuestionContainer key={++index}>
                        <Question>{sondage.question}</Question>
                        {sondage.description && (<Description style={{fontStyle: 'italic', textAlign: 'justify', width: '100%'}}>{sondage.description || ''}</Description>)}
                        <Hr />
                        <ReponseList create={this.createResponseList} type={sondage.type} _id={sondage._id} responses={sondage.responses} />
                    </QuestionContainer>
                ))}
                <ButtonContainer>
                    <Button disabled={this.state.btnLoading} onPress={() => this.sendMyAnswers(true)}>
                        {this.state.btnLoading && (
                            <ActivityIndicator color='#FFF' />
                        )}
                        <Text>Envoyer mes réponses</Text>
                    </Button>
                </ButtonContainer>
            </Container>
        );
    }


}


export default SondageList;
