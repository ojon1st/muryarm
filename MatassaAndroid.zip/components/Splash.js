import React from 'react';
import { StatusBar } from 'react-native';
import Styled from 'styled-components/native';

import logo from '../assets/logo.png';

const Container = Styled.View`
    flex: 1;
    align-items: center;
    justify-content: center;
`;

const Image = Styled.Image`
    width: 100%;
    resizeMode: contain;
`;

class Splash extends React.Component {
    render() {
        return (
            <Container>
                <StatusBar backgroundColor='#FFF' barStyle='light-content' />
                <Image
                    source={logo}
                />
            </Container>
        );
    }
}

export default Splash;