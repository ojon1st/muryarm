import React from 'react';
import { AsyncStorage, ActivityIndicator } from 'react-native';
import Styled from 'styled-components/native';
import Icon from 'react-native-vector-icons/FontAwesome5';

import { URL } from '../ressources/config';

const Container = Styled.View`
    flex: 1;
    align-items: center;
    justify-content: center;
    background-color: #f5f5f5;
`;

const Title = Styled.Text`
    color: #0062FFB2;
    text-align: center;
    width: 70%;
    margin: 10px;
    margin-bottom: 30px;
    font-size: 18px;
    font-weight: bold;
`;

const Username = Styled.TextInput`
    width: 80%;
    padding: 10px;
    margin: 5px;
    border-radius: 4px;
    font-size: 17px;
    color: #0062FF;
    font-weight: bold;
    elevation: 1;
    background-color: #fff;
`;

const Password = Styled(Username)`
    font-size: 17px;
`;

const Text = Styled.Text`
    color: #fff;
    font-weight: bold;
    text-align: center;
`;


const Button = Styled.TouchableOpacity`
    width: 80%;
    margin-top: 10px;
    padding: 10px;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    background-color: #0062FF;
    border-radius: 4px;
`;

const TransparentButton = Styled(Button)`
    background-color: transparent;
    justify-content: flex-end;
    margin: 5px;
`;

const Message = Styled.Text`
    position: absolute;
    top: 0;
    width: 100%;
    padding: 4px 10px;
    background-color: red;
    color: #fff;
    font-weight: bold;
    elevation: 2;
    zIndex: 100000
`;

class UserForm extends React.Component {

    state = {
        newUser: false,
        message: false,
        btnLoading: false,
        username: '',
        password: '',
        confirmation: ''
    }


    addUser = async () => {
        try {
            let {username, password, confirmation} = this.state;
            if((username.trim().length > 0) && (password.trim().length > 0)) {

                if(password !== confirmation) {
                    return this.setState({
                        message: "Les deux mots de passe ne correspondent pas."
                    });
                }
                this.setState({
                    message: false,
                    btnLoading: true
                });
                let response = await fetch(`${URL}/addUser`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        username,
                        password
                    })
                }).then(res => res.json());
                if(response.success) {
                    await AsyncStorage.setItem('@muryarmatassa:user', JSON.stringify(response.data));
                    this.setState({
                        btnLoading: false
                    });
                    this.props.navigation.goBack();
                } else {
                    this.setState({
                        btnLoading: false,
                        message: response.moreInfos
                    });
                }
            } else {
                this.setState({
                    message: "Certaines informations sont manquantes."
                });
            }
        } catch(err) {
            console.log(err.message);
            this.setState({
                btnLoading: false,
                message: "Nous n'arrivons pas à envoyer votre requête, merci de vérifier votre connexion à Internet."
            });
        }
    }

    connectUser = async () => {
        try {
            let { username, password } = this.state;
            console.log(username, password);
            if (username.trim().length && password.trim().length) {
                this.setState({
                    message: false,
                    btnLoading: true
                });
                let response = await fetch(`${URL}/connectUser`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        username,
                        password
                    })
                }).then(res => res.json());
                if (response.success) {
                    await AsyncStorage.setItem('@muryarmatassa:user', JSON.stringify(response.data));
                    this.setState({
                        btnLoading: false
                    });
                    this.props.navigation.goBack();
                } else {
                    this.setState({
                        message: response.moreInfos,
                        btnLoading: false
                    });
                }
            } else {
                this.setState({
                    message: "Certaines informations sont manquantes."
                });
            }
        } catch (err) {
            this.setState({
                btnLoading: false,
                message: "Nous n'arrivons pas à envoyer votre requête, merci de vérifier votre connexion à Internet."
            });
        }
    }

    onUsernameChange = (username) => {
        this.setState({
            username
        })
    }

    onConfirmationChange = (confirmation) => {
        this.setState({
            confirmation
        })
    }

    onPasswordChange = (password) => {
        this.setState({
            password
        })
    }

    onChangeTypeClicked = () => {
        this.setState({
            message: false,
            newUser: !this.state.newUser
        });
    }

    render() {


        console.log(this.props.navigation)

        return (
            <Container>
                {this.state.message && (<Message>{this.state.message}</Message>)}
                <Icon name="user" size={70} color="#0062FF" />
                <Title>{this.state.newUser ? "Renseignez ce formulaire pour créer votre compte":"Saissiez vos information d'identification pour continuer"}</Title>
                <Username 
                    placeholder="Nom d'utilisateur"
                    value={this.state.username}
                    returnKeyType="next"
                    blurOnSubmit={true}
                    autoCompleteType="off"
                    onChangeText={this.onUsernameChange}
                />
                <Password 
                    placeholder="Mot de passe"
                    value={this.state.password}
                    returnKeyType="next"
                    blurOnSubmit={true}
                    secureTextEntry={true}
                    autoCompleteType="off"
                    onChangeText={this.onPasswordChange}
                />
                {this.state.newUser && (
                    <Password
                        placeholder="Confirmation"
                        value={this.state.confirmation}
                        returnKeyType="done"
                        blurOnSubmit={true}
                        secureTextEntry={true}
                        autoCompleteType="off"
                        onChangeText={this.onConfirmationChange}
                    />
                )}
                <TransparentButton onPress={this.onChangeTypeClicked}><Text style={{color: '#999', fontWeight: 'normal', textAlign: 'right', fontStyle: 'italic', textDecorationLine: 'underline'}}>{this.state.newUser ? "J'ai déjà un compte" : "Créer un compte"}</Text></TransparentButton>
                <Button onPress={this.state.newUser ? this.addUser : this.connectUser}>
                    {this.state.btnLoading && (
                        <ActivityIndicator color="#fff" />
                    )}
                    <Text>{this.state.newUser ? 'Inscription' : 'Connexion'}</Text>
                </Button>
            </Container>
        );

    }
}

export default UserForm;