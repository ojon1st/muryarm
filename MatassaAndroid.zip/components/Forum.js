import React from 'react';
import { StatusBar, ActivityIndicator } from 'react-native';
import Styled from 'styled-components/native';
import Icon from 'react-native-vector-icons/FontAwesome5';

import distance from '../assets/distance_entre_personnes.png';
import contacts from '../assets/eviter_les_contacts.png';
import fatigue from '../assets/fatigue.png';
import mains from '../assets/laver_les_mains.png';
import respiration from '../assets/respiration.png';
import temperature from '../assets/temperature.png';
import tousser from '../assets/tousser.png';
import virus from '../assets/virus.png';

import { URL } from '../ressources/config';

const Container = Styled.ScrollView`
    backgroundColor: #f5f5f5;
    flex: 1;
`;

const Header = Styled.ImageBackground`
    height: 200px;
    background-color: #0062FFb4;
    align-items: center;
    justify-content: center;
    paddingHorizontal: 15px;
    resizeMode: cover;
`;

const BoldTitle = Styled.Text`
    font-weight: bold;
    color: #fff;
    font-size: 28px;
    line-height: 30px;
    text-align: center;
`;

const LightTitle = Styled.Text`
    color: rgba(250,250,250, 0.8);
    text-align: center;
    margin-top: 5px;
`;

const Body = Styled.View`
    flex: 1;
`;

const Text = Styled.Text`
    color: #bbb;
    font-weight: bold;
    font-size: 18px;
`;

class Accueil extends React.Component {

    render() {
        return (
            <Container>
                <StatusBar backgroundColor='#0062FF' barStyle='light-content' />
                <Header source={virus}>
                    <BoldTitle>La jeunesse du Niger s'engage contre le Coronavirus...</BoldTitle>
                    <LightTitle>#Covid19 - NIGER</LightTitle>
                </Header>
                <Body style={{height: 270, alignItems: 'center', justifyContent: 'center'}}>
                    <Text>Bientôt votre forum public</Text>
                </Body>
            </Container>
        );
    }
}


export default Accueil;